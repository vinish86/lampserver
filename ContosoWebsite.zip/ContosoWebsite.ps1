Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
    #Disable Floppy disk and CD ROM devices
    Script Disable-PnpDevice 
    {
      GetScript = {@{}}
      TestScript = {
        return $false
      }
      SetScript = {
        $disableFloppyDisk = Get-PnpDevice| Where-Object {$_.friendlyname -like "Floppy disk drive"}
        $disableFloppyDisk  | Disable-PnpDevice -Confirm:$false
        $disableCDDrive = Get-PnpDevice| Where-Object {$_.friendlyname -like "Msft Virtual CD/ROM ATA Device"}
        $disableCDDrive  | Disable-PnpDevice -Confirm:$false
      }
    }
  }
} 
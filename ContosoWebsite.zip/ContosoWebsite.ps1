Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
    Set-StrictMode -Off
    Import-DscResource -ModuleName xPSDesiredStateConfiguration  
    Import-DscResource -ModuleName PSDesiredStateConfiguration 
    Import-DsCResource -ModuleName xPendingReboot
    Import-DSCResource -ModuleName xComputerManagement

    LocalConfigurationManager 
    {
        RebootNodeIfNeeded = $True
    }
    	#Init DataDrive
	
	xWaitforDisk Disk2
  {
      DiskNumber = 2
      RetryIntervalSec = 2
      RetryCount = 300
  }

  xDisk FVolume
  {
      DiskNumber = 2
      DriveLetter = 'F'
      FSLabel = 'Data'
      DependsOn = '[xWaitForDisk]Disk2'
      

  }

  xWaitForVolume FDrive {
  DriveLetter = 'F'
  RetryIntervalSec = 2
  RetryCount = 60
  }
    #Disable Floppy disk and CD ROM devices
    Script Disable-PnpDevice 
    {
      GetScript = {@{}}
      TestScript = {
        return $false
      }
      SetScript = {
        if ((Get-PnpDevice | Where-Object {$_.friendlyname -like "Msft Virtual CD/ROM ATA Device"}).Status -eq 'OK')
        {
        $disableCDDrive = Get-PnpDevice| Where-Object {$_.friendlyname -like "Msft Virtual CD/ROM ATA Device"}
        $disableCDDrive  | Disable-PnpDevice -Confirm:$false 
        }     
        if ((Get-PnpDevice| Where-Object {$_.friendlyname -like "Floppy disk drive"}).Status -eq 'OK')
        {
        $disableFloppyDisk = Get-PnpDevice| Where-Object {$_.friendlyname -like "Floppy disk drive"}
        $disableFloppyDisk  | Disable-PnpDevice -Confirm:$false
        }
      }
    }
    }
  }
} 
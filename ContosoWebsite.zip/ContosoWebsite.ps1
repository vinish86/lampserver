Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
    #Disable Floppy disk and CD ROM devices
    Script Disable-PnpDevice 
    {
      GetScript = {@{}}
      TestScript = {
        return $false
      }
      SetScript = {
        if ((Get-PnpDevice | Where-Object {$_.friendlyname -like "Msft Virtual CD/ROM ATA Device"}).Status -eq 'OK')
        {
        $disableCDDrive = Get-PnpDevice| Where-Object {$_.friendlyname -like "Msft Virtual CD/ROM ATA Device"}
        $disableCDDrive  | Disable-PnpDevice -Confirm:$false 
        }     
        if ((Get-PnpDevice| Where-Object {$_.friendlyname -like "Floppy disk drive"}).Status -eq 'OK')
        {
        $disableFloppyDisk = Get-PnpDevice| Where-Object {$_.friendlyname -like "Floppy disk drive"}
        $disableFloppyDisk  | Disable-PnpDevice -Confirm:$false
        }
      }
    }

    Script DataDisk-NewFileSystemLabel
    {
      GetScript = {@{}}
      TestScript = {
        return $false
      }
      SetScript = {
        Get-Disk |
        Where-Object partitionstyle -eq 'raw' |
        Initialize-Disk -PartitionStyle MBR -PassThru |
        New-Partition -AssignDriveLetter -UseMaximumSize |
        Format-Volume -FileSystem NTFS -NewFileSystemLabel "D" -Confirm:$false
      }
    }
  }
} 
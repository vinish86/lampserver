Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
    LocalConfigurationManager 
    {
        RebootNodeIfNeeded = $True
    }
    #Disable Floppy disk and CD ROM devices
    Script Disable-PnpDevice 
    {
      GetScript = {@{}}
      TestScript = {
        return $false
      }
      SetScript = {
        if ((Get-PnpDevice | Where-Object {$_.friendlyname -like "Msft Virtual CD/ROM ATA Device"}).Status -eq 'OK')
        {
        $disableCDDrive = Get-PnpDevice| Where-Object {$_.friendlyname -like "Msft Virtual CD/ROM ATA Device"}
        $disableCDDrive  | Disable-PnpDevice -Confirm:$false 
        }     
        if ((Get-PnpDevice| Where-Object {$_.friendlyname -like "Floppy disk drive"}).Status -eq 'OK')
        {
        $disableFloppyDisk = Get-PnpDevice| Where-Object {$_.friendlyname -like "Floppy disk drive"}
        $disableFloppyDisk  | Disable-PnpDevice -Confirm:$false
        }
      }
    }
    Script DataDisk-NewFileSystemLabel
    {
      GetScript = {@{}}
      TestScript = {
        return $false
      }
      SetScript = {
        Get-Disk |
        Where-Object partitionstyle -eq 'raw' |
        Initialize-Disk -PartitionStyle MBR -PassThru |
        New-Partition -AssignDriveLetter -UseMaximumSize |
        Format-Volume -FileSystem NTFS -NewFileSystemLabel "D" -Confirm:$false
      }
    }
    Script PaginationFromDToZ     {
      GetScript = {@{}}
      TestScript = {
        return $false
      }
      SetScript = {
        if ((Get-WmiObject -Class Win32_PageFileUsage  -ComputerName $env:computername | where {$_.Name -like "D:\pagefile.sys"}).Name -eq "D:\pagefile.sys") {
          Set-WMIInstance -class Win32_PageFileSetting -Arguments @{name="c:\pagefile.sys"}
          $CurrentPageFile = Get-WmiObject -Query "select * from Win32_PageFileSetting where name='d:\\pagefile.sys'"
          $CurrentPageFile.delete()
          Restart-Computer -Force
          }
      }
    }
    Script RenameTempDriveNameToZ     {
      GetScript = {@{}}
      TestScript = {
        return $false
      }
      SetScript = {
          Get-Partition -DriveLetter D | Set-Partition -NewDriveLetter Z
          Get-WmiObject Win32_PageFileusage
          Set-WMIInstance -class Win32_PageFileSetting -Arguments @{name="Z:\pagefile.sys"}
          $CurrentPageFile = Get-WmiObject -Query "select * from Win32_PageFileSetting where name='c:\\pagefile.sys'"
          $CurrentPageFile.delete()
          Restart-Computer -Force
          }
      }
    }
  }
} 
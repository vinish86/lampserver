Configuration ContosoWebsite
{
  param ($MachineName)
 
  Import-DscResource -ModuleName MoveAzureTempDrive, xComputerManagement
  
  Node $MachineName
  {
    LocalConfigurationManager 
    {
        RebootNodeIfNeeded = $True
    }
    #Disable Floppy disk and CD ROM devices
    Script Disable-PnpDevice 
    {
      GetScript = {@{}}
      TestScript = {
        return $false
      }
      SetScript = {
        if ((Get-PnpDevice | Where-Object {$_.friendlyname -like "Msft Virtual CD/ROM ATA Device"}).Status -eq 'OK')
        {
        $disableCDDrive = Get-PnpDevice| Where-Object {$_.friendlyname -like "Msft Virtual CD/ROM ATA Device"}
        $disableCDDrive  | Disable-PnpDevice -Confirm:$false 
        }     
        if ((Get-PnpDevice| Where-Object {$_.friendlyname -like "Floppy disk drive"}).Status -eq 'OK')
        {
        $disableFloppyDisk = Get-PnpDevice| Where-Object {$_.friendlyname -like "Floppy disk drive"}
        $disableFloppyDisk  | Disable-PnpDevice -Confirm:$false
        }
      }
    }
    Script DataDisk-NewFileSystemLabel
    {
      GetScript = {@{}}
      TestScript = {
        return $false
      }
      SetScript = {
        Get-Disk |
        Where-Object partitionstyle -eq 'raw' |
        Initialize-Disk -PartitionStyle MBR -PassThru |
        New-Partition -AssignDriveLetter -UseMaximumSize |
        Format-Volume -FileSystem NTFS -NewFileSystemLabel "D" -Confirm:$false
      }
    }
    Script DisablePageFile
    {
    
        GetScript  = { @{ Result = "" } }
        TestScript = { 
           $pf=Get-WmiObject win32_pagefilesetting
           #There's no page file so okay to enable on the new drive
           if ($pf -eq $null)
           {
                return $true
           }
           #Page file is still on the D drive
           if ($pf.Name.ToLower().Contains('d:'))
           {
                return $false
           }

           else
           {
                return $true
           }
        
        }
        SetScript  = {
            #Change temp drive and Page file Location 
            Get-WmiObject win32_pagefilesetting
            $pf=Get-WmiObject win32_pagefilesetting
            $pf.Delete()
            Restart-Computer -Force
        }
       
    }
    MoveAzureTempDrive MoveAzureTempDrive
    {
   
    TempDriveLetter = "Z"           
    }
    }
  }
} 